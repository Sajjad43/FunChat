package com.example.text;

import java.io.DataInputStream;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Date;


import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.media.RingtoneManager;
import android.os.Handler;
import android.util.Log;

public class ImageSocket65000 extends Thread{

	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	Socket socket;
	DataOutputStream dataOutputStream;
	DataInputStream dataInputStream;
	String userNumber="";
	String imagename="";
	String senderphonenumber="";
	byte[] data=null;
	private static int i=0;
	Activity activity;
	int datalength=0; 

	@Override
	public void run() {
		// TODO Auto-generated method stub

		super.run();

		String userNameAndphone=readfile();
		//read(activity.getApplicationContext());
		String[] namePhone=new String[3];
		namePhone=userNameAndphone.split(" ");
		this.userNumber=namePhone[1];

		try {
			//socket
			socket=new Socket(IP.Ip,65000);
			dataOutputStream=new DataOutputStream(socket.getOutputStream());
			dataInputStream=new DataInputStream(socket.getInputStream());

			dataOutputStream.writeUTF(userNumber);

			//receive  the image
			while(true){







				this.senderphonenumber=this.dataInputStream.readUTF();
				this.imagename=this.dataInputStream.readUTF();


				datalength=this.dataInputStream.readInt();

				data=new byte[datalength];

				this.dataInputStream.readFully(data, 0, data.length);

				if(ActivityStatus()){

					Log.d("Sajjad", "ImageSocket- Activity Status for image is yes");

					BitmapFactory.Options option=new BitmapFactory.Options();
					//reducing the size while decoding
					option.inSampleSize=3;
					BitmapFactory factory=new BitmapFactory();

					Bitmap bitmap=factory.decodeByteArray(data,0, data.length,option);

					//save the image to the sdcard
					BitmapSdCard sdCard=new BitmapSdCard();
					sdCard.writeImage(bitmap, imagename);

					//send the broadcast
					Intent intent=new Intent("com.example.text.Third_Activity1");
					intent.putExtra("imagename",this.imagename);
					Service_Socket.service.sendBroadcast(intent);
					Log.d("Sajjad", "Image intent send broadcast");

				}
				else{

					BitmapFactory factory=new BitmapFactory();
					BitmapFactory.Options option=new BitmapFactory.Options();
					//reducing the size while decoding
					option.inSampleSize=3;

					//convert the byte array to bitmap
					Bitmap bitmap=factory.decodeByteArray(data,0, data.length);
					//store the bitmap in the sd card
					storeinSdcard(bitmap);
					//send the notification
					Notificate notifi=new Notificate(Service_Socket.service.mapService.get(this.senderphonenumber).getName(),senderphonenumber,
							this.imagename,1);
					notifi.notifies();

					Log.d("Sajjad", "send notification");

				}
			}


		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In ImageSocket run(),Exception- "+e.getLocalizedMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In ImageSocket run(),Exception- "+e.getLocalizedMessage());

		}

	}
	public String readfile(){
		//read the profile file
		FileStatus file=new FileStatus(Service_Socket.service);
		return file.readfromfile("profile");


	}
	public void  storeinSdcard(Bitmap bitmap){
		//store bitmap in the sdcard
		BitmapSdCard sdCard=new BitmapSdCard();
		sdCard.writeImage(bitmap, imagename);
 
	}

	public boolean ActivityStatus(){

		String[] string=new String[2];
		boolean status=false;
		FileStatus file=new FileStatus(Service_Socket.service);
		Log.d("Sajjad","ImageSocket- check Activity status" );
		String file_status=file.readfromfile("Activity");
		if(file_status.equals("Nothing")){

			status=false;
		
		}
		else{
		
			string=file.readfromfile("Activity").split(" ");
			
			Log.d("Sajjad",string[0]+" "+string[1]);
			
			if(string[0].equals("ActivityTwo")){
			
				if(string[1].equals(this.senderphonenumber))
				{
					status=true;
				}
				else{
				
					status=false;
				
				}
			}

		}

		return status;
	}
	/**
	 * @return the activity
	 */
	public Activity getActivity() {
		return activity;
	}
	/**
	 * @param activity the activity to set
	 */
	public void setActivity(Activity activity) {
		this.activity = activity;
	}


}
