package com.example.text;

public class Notitype {

	String name,number,filename_message,time;
	int type;

	public Notitype(String name, String number, String filename_message, int type, String time) {
		super();
		this.name = name;
		this.number = number;
		this.filename_message = filename_message;
		this.type = type;
		 
		this.time = time;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	 
	 
 

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getFilename_message() {
		return filename_message;
	}

	public void setFilename_message(String filename_message) {
		this.filename_message = filename_message;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	
	
}
