package com.example.text;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.os.Environment;
import android.util.Log;

public class BitmapSdCard {


	public void writeImage(Bitmap bitmap,String imagename){

		//save the image to the SD card using the image name
		File file=new File(Environment.getExternalStorageDirectory()+"/DCIM/Camera/");

		System.out.print(file.toString());

		//set the path
		String pathname=file.toString()+"/"+imagename+".jpg";


		try {

			//write image data to the file
			FileOutputStream outputStream=new FileOutputStream(pathname);

			BufferedOutputStream buffer=new BufferedOutputStream(outputStream);

			bitmap.compress(CompressFormat.JPEG, 50, buffer);

			//close the buffer
			buffer.flush();
			buffer.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In Bitmapsccard writeImage(),Exception- "+e.getLocalizedMessage());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In Bitmapsccard writeImage(),Exception- "+e.getLocalizedMessage());

		}

	}
	public Bitmap readImage(String filename){

		//read image from the file using the image name
		File file=new File(Environment.getExternalStorageDirectory()+"/DCIM/Camera/");

		//set the path
		String pathname=file.toString()+"/"+filename+".jpg";

		//get the image
		Bitmap bitmap=decodeBitmap(pathname,200,150);

		return bitmap;

	}
	public Bitmap decodeBitmap(String filename,int width,int height){

		BitmapFactory.Options option=new BitmapFactory.Options();
		//get the information of the image before loading to the memory
		option.inJustDecodeBounds=true;
		BitmapFactory.decodeFile(filename, option);
		option.inSampleSize=getSamplingFactor(option,width,height);

		//load the image to the memory
		option.inJustDecodeBounds=false;
		return  BitmapFactory.decodeFile(filename, option);

	}

	public int getSamplingFactor(BitmapFactory.Options options, int reqWidth, int reqHeight){

		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			final int halfHeight = height / 2;
			final int halfWidth = width / 2;

			// Calculate the largest inSampleSize value that is a power of 2 and keeps both
			// height and width larger than the requested height and width.
			while ((halfHeight / inSampleSize) > reqHeight
					&& (halfWidth / inSampleSize) > reqWidth) {
				inSampleSize *= 2;
			}
		}

		return inSampleSize;

	}


	//todo list

	//read and write the friendimage to and from the funchat folder 
	//read the profile image from the funchat folder 



	public void writeFriendImage(Bitmap bitmap,String imagename){

		//save the image to the SD card using the image name
		File file2=new File(Environment.getExternalStorageDirectory()+"/DCIM/FunChat/");

		file2.mkdir();

		Log.d("Sajjad","write image");

		File file=new File(Environment.getExternalStorageDirectory()+"/DCIM/FunChat/");


		System.out.print(file.toString());

		String nameModified="";

		if(imagename.substring(imagename.length()-4,imagename.length()).equals(".JPG")||imagename.substring(imagename.length()-4,imagename.length()).equals(".jpg")){
			nameModified=imagename.substring(0,imagename.length()-4);

		}
		else{
			nameModified=imagename;
		}

		//set the path
		String pathname=file.toString()+"/"+nameModified+".jpg";


		try{

			if(file.exists()){


				//write image data to the file
				FileOutputStream outputStream=new FileOutputStream(pathname);

				BufferedOutputStream buffer=new BufferedOutputStream(outputStream);

				bitmap.compress(CompressFormat.JPEG, 50, buffer);

				buffer.flush();
				buffer.close();
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In Bitmapsccard writeImage(),Exception- "+e.getLocalizedMessage());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In Bitmapsccard writeImage(),Exception- "+e.getLocalizedMessage());

		}
	}


	public Bitmap readFriendImage(String filename){

 		//get the image
		Bitmap bitmap=decodeBitmap(filename,43,43);

		return bitmap;
	}


	public Bitmap readImageforProfile(String filename){

		Bitmap bitmap=this.decodeBitmap(filename, 120, 120);

		return bitmap;
	}


}
