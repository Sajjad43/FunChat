package com.example.text;

import java.io.DataInputStream;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

public class Fetch_friendimage_Socket implements Runnable{

	ArrayList<String> numberList;
	Context context;
	int flag;

	public Fetch_friendimage_Socket(Context context,int flag) {
		super();
		this.context = context;
		this.flag=flag;

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		//get the name and the number

		numberList=new ArrayList<String>();

		String userNameAndphone=readfile();
		Log.d("Sajjad", "The username and phone are"+userNameAndphone);
		String[] namePhone=new String[2];
		namePhone=userNameAndphone.split(" ");
		FileStatus file=new FileStatus(context);


 		if(flag==2){
			Log.d("Sajjad","Fetch friend socket thread running due to service friend image");

		}
		else{

			Log.d("Sajjad","Fetch friend socket thread running due to service Socket image");

		}

		//use a Arraylist here 

		//initialize the socket 
		//datainputStream and outputStream
		//connect to the server

		if(file.isFile("FriendList")==false&&flag==2){

			file.createFileActivity("FriendList");
			LoadingContacts_thread loadingcontacts=new LoadingContacts_thread(context,numberList,flag);
			loadingcontacts.start();
		
		}
		else{

			this.numberList=file.fetchFriendlist("FriendList");

			SendFriendList send=new SendFriendList(context ,numberList,flag);
			send.start();
			//fetch the arraylist from the friends file;
		}


		//----Loop---
		//send the arraylist size 
		//send all the number 
		//----Loop
		/*try {

			outputStream.writeInt(numberList.size());
			Log.d("Sajjad", "FetchFriendSocket,NUmber are sending");
			for(int i=0;i<10;i++){


				outputStream.writeUTF(numberList.get(i));
			}

			//get the list size  
			//use a loop
			//get the number along with the image 

			//if yes ,get the image, store the photo on the funchat folder along with the number

			//remove the number to a arraylist 
			//loop--

			int listsize=inputStream.readInt();
			Log.d("Sajjad", "FetchFriendSocket,Image are receiving");

			for(int j=0;j<listsize;j++){

				String imagename=inputStream.readUTF(); 
				int byte_size=inputStream.readInt();
				byte[]	data=new byte[byte_size];

				inputStream.readFully(data);
				Log.d("Sajjad","Fetch_friendSocket,imagename is "+imagename);

				if(imagename.length()>=11){

					String temp1=imagename.substring(0,11);
					this.numberList.remove(temp1);

				}
				else{

					this.numberList.remove(imagename);

				}

				String temp=(namePhone[1]+".jpg");

				if(!imagename.equals(temp)){

					//convert the byte array to  bitmap
					BitmapFactory.Options option=new BitmapFactory.Options();
					option.inSampleSize=4;

					BitmapFactory factory=new BitmapFactory();
					Bitmap bitmap=factory.decodeByteArray(data, 0, byte_size,option);

					//store the bitmap
					BitmapSdCard store=new BitmapSdCard();

					Log.d("Sajjad","bitmap-"+bitmap);

					store.writeFriendImage(bitmap, imagename);
					Log.d("Sajjad","Fetch_friendsocket,"+imagename+"is store to sdcard");

				}	

			}
			//store the arraylist on a file so that on the next time we can get to know the list of number whose photos are pending to fetch from server

			file.writeFriendList("FriendList",numberList);



			//if flag==2
			//dismiss the progressDialog using MainActivity as the reference 
			//finish the activity


			//if the call of this object is from Service_Friend i.e flag==2,
			//start the service_socket and then 
			//then move to second activity

			//here,put a value with the intent to make the service understand that the call for service coming from 
			//fetch_friend
			//value would be 2 

			//else do nothing 

			if(flag==2& MainActivity.main!=null)
			{

				if(file.isFile(("Service"))){

					if(file.readfromfile("Service").equals("true")){

					}
					else
					{ 
						Intent intentService=new Intent(context,Service_Socket.class);
						intentService.putExtra("flag",2);
						(MainActivity.main).startService(intentService);

					}
				}
				else{

					Intent intentService=new Intent(context,Service_Socket.class);
					intentService.putExtra("flag",2);
					(MainActivity.main).startService(intentService);

				}

				Service_FriendsImage.service_friend.stopForeground(true);

				//start the second Activity
				MainActivity.main.runOnUiThread(new Runnable(){

					@Override
					public void run() {
						// TODO Auto-generated method stub
						Log.d("Sajjad","got ok message");

						Intent intent=new Intent(context,Second_activity.class);
						MainActivity.main.dialog.dismiss();
						MainActivity.main.dialog.cancel();
						Log.d("Sajjad","FetchfriendSocket,remove foreground & move to second activity");
						MainActivity.main.startActivity(intent);
						MainActivity.main.overridePendingTransition(R.anim.slide_left,R.anim.slide_right);
						MainActivity.main.finish();

					}

				});





	}



} catch (IOException e) {
	// TODO Auto-generated catch block
	Log.d("Sajjad","Fetch exception");
}*/






	}
	public String readfile(){

		FileStatus file=new FileStatus(context);

		return file.readfromfile("profile");
	}

}
