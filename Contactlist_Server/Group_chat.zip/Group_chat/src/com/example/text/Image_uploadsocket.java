package com.example.text;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import android.util.Log;

public class Image_uploadsocket extends Thread{

	Socket socket;
	DataOutputStream outputStream;

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		Log.d("Sajjad","ImageUpload");

		try {
			//set the socket with ip and port
			socket=new Socket(IP.Ip,6000);
			
			outputStream=new DataOutputStream(socket.getOutputStream());

			String userNameAndphone=readfile();
			Log.d("Sajjad", "The username and phone are"+userNameAndphone);
			String[] namePhone=new String[2];
			namePhone=userNameAndphone.split(" ");

			
			//send the name and the number of the mobile user to server
			outputStream.writeUTF(namePhone[0]);
			outputStream.writeUTF(namePhone[1]);
			
			Log.d("Sajjad","sent  name and number to server in ImageUpload");



		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","Imageupload exception");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","Imageupload exception");
		}


	}
	public String readfile(){

		//read the mobile user name and number from the File 
		FileStatus file=new FileStatus(Service_Socket.service);
		return file.readfromfile("profile");


	}

}
