package com.example.text;

import java.io.IOException;

import android.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;


public class Messaging extends Fragment implements OnClickListener{



	static Messaging fragments;	
	static LinearLayout linearlayout;
	static EditText textbox;

	Context CoNtext; 
	TextView chatPersonText ;
	static ScrollView scrollview;

	String chatnumber,message1,messagebox_sent,message,imagename;

	Bitmap image,bitmap;

	int index=0;

	public Messaging(String chatnumber,String message,String imagename)
	{
		this.chatnumber=chatnumber; 
		this.imagename=imagename;
		this.message=message;
	}


	 
	@Override
	public void onResume() {
		// TODO Auto-generated method stub

		super.onResume();

		fragments=this;

		if(message!=null)
		{
			this.addViewforMessageReceive(message.toString());
			message=null;
		}

		if(imagename!=null){

			setImageNotification();

		}

	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		Log.d("Sajjad","Messaging Fragment has been created");



		//inflate the  view for the fragment
		View view=inflater.inflate(R.layout.messaging,null,false);

		RelativeLayout relativeLayout =(RelativeLayout)view;


		TextView header=(TextView)view.findViewById(R.id.header);

		header.setText("Texting is fun");

		//scrollview of the messaging fragment  

		scrollview=(ScrollView)view.findViewById(R.id.scrollView1) ; 

		//framelayout of the messaging fragment  

		this.linearlayout=(LinearLayout)view.findViewById(R.id.message_one);



		//textbox of the messaging fragment  		
		textbox=(EditText)view.findViewById(R.id.message_two);

		//button to send the text in the messaging gui     
		Button sendtext=(Button)view.findViewById(R.id.message_two_buton);
		sendtext.setOnClickListener(this);



		return  view; 


	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Log.d("Sajjad","sent button click");


		// button is clicked and then view of the text from the username would be added to the linearlayout 


		if(v==(Button)this.getActivity().findViewById(R.id.message_two_buton))
		{
			this.linearlayout.post(new Runnable(){

				@Override
				public void run() {
					// TODO Auto-generated method stub

					View view=addViewforMessageSent();

					linearlayout.addView(view);

					// message=Messaging.textbox.getText().toString();s
				}


			});
			//get the text from textbox
			messagebox_sent=Messaging.textbox.getText().toString();

			Thread thread=new Thread(new Runnable(){

				@Override
				public void run() {
					// TODO Auto-generated method stub

					try {

						Log.d("Sajjad","Service "+Service_Socket.service.socket_client.outputStream+"chatnumber "+chatnumber);
 
						Service_Socket.service.socket_client.outputStream.writeUTF(chatnumber);

						Service_Socket.service.socket_client.outputStream.writeUTF(messagebox_sent);

					} catch (IOException e) {
						// TODO Auto-generated catch block
						Log.d("Sajjad","In Messaging Onclickrun(),Exception- "+e.getLocalizedMessage());

					
					}

					Log.d("Sajjad","Usertext- "+messagebox_sent+" is sent to server");


				}

			});
			thread.start();



			// TODO Auto-generated method stub
			Messaging.scrollview.postDelayed(new Runnable(){

				@Override
				public void run() {
					// TODO Auto-generated method stub
					Messaging.scrollview.fullScroll(ScrollView.FOCUS_DOWN);
				}

			},1500);

			Messaging.textbox.setText("");
		}
		else{
			
			TextView textview=(TextView) v.findViewById(R.id.imagetext);
			Intent intent=new Intent(this.getActivity().getApplicationContext(),ImageDisplayActivity.class);
			
			intent.putExtra("filename",imagename);
			this.getActivity().startActivity(intent);
			
		}

	}

	public void setImageNotification(){

		this.CoNtext=Third_Activity.third.getApplicationContext();

		new Thread(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub

				Thread thread=new Thread(new Runnable(){

					@Override
					public void run() {
						// TODO Auto-generated method stub
						BitmapSdCard sdCard=new BitmapSdCard();
						bitmap=sdCard.readImage(imagename);
					
					    Third_Activity.third.runOnUiThread(new Runnable(){

							@Override
							public void run() {
								// TODO Auto-generated method stub
								fragments.addImageView(bitmap,imagename);
							}
					    	
					    	
					    	
					    });
					
					
					
					}
                      
				});
				thread.start();
				

				 


			}

		}).start();
	}


	public  View addViewforMessageSent()
	{
		Log.d("Sajjad","Sent View added to Linearlayout");

		//View for username

		LayoutInflater inflater = (LayoutInflater)this.getActivity().getApplicationContext().getSystemService
				(Context.LAYOUT_INFLATER_SERVICE);

		View view=inflater.inflate(R.layout.text_2,null);

		view.setMinimumHeight(40);

		RelativeLayout relativelayout=(RelativeLayout)view;

		TextView usernameText=(TextView)relativelayout.getChildAt(0);

		usernameText.setText(messagebox_sent);

		return view;
	}
	public void addImageView(Bitmap bitmap,String title){
		Log.d("Sajjad","Receiver ImageView added to Linearlayout");

		this.image=bitmap;
		this.imagename=title;

		this.linearlayout.post(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				View v=ImageSubView(image,imagename);

				linearlayout.addView(v);
				Messaging.scrollview.fullScroll(ScrollView.FOCUS_DOWN);

			}

		});
		this.scrollview.postDelayed(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				Messaging.scrollview.fullScroll(ScrollView.FOCUS_DOWN);
			}

		},1200);







	}

	public void addViewforMessageReceive(String messageReceive){
		Log.d("Sajjad","Receiver View added to Linearlayout");

		//View for chatperson
		this.message1=messageReceive;

		this.linearlayout.post(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				View v=getSubView(message1);

				linearlayout.addView(v);
				Messaging.scrollview.fullScroll(ScrollView.FOCUS_DOWN);


			}

		});
		this.scrollview.postDelayed(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				Messaging.scrollview.fullScroll(ScrollView.FOCUS_DOWN);
			}

		},150);



	}
	private View getSubView(String message)
	{
		//view for chatperson  inflated

		LayoutInflater inflater = (LayoutInflater)this.getActivity().getApplicationContext().getSystemService
				(Context.LAYOUT_INFLATER_SERVICE);
		View view=inflater.inflate(R.layout.text,null);
		view.setMinimumHeight(40);
		LinearLayout linearlayout=(LinearLayout)view;
		TextView chatPersontext=(TextView)linearlayout.getChildAt(0);
		chatPersontext.setText(message);

		return view;


	}
	private View ImageSubView(Bitmap bitmap,String title){
		LayoutInflater inflater = (LayoutInflater)this.getActivity().getApplicationContext().getSystemService
				(Context.LAYOUT_INFLATER_SERVICE);
		View v=inflater.inflate(R.layout.image, null);
		v.setOnClickListener(this);

		ImageView imageview=(ImageView) v.findViewById(R.id.imageView1);
		TextView text=(TextView)v.findViewById(R.id.imagetext);
		//imageview.setContentDescription(tSitle);
		imageview.setImageBitmap(bitmap.createScaledBitmap(bitmap,200,150, true));
		text.setText(title);
		return v;
	}

}