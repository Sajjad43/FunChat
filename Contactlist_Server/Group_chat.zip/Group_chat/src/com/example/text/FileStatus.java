package com.example.text;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;

import android.content.Context;
import android.util.Log;

public class FileStatus {

	Context context;

	public FileStatus(Context context) {
		super();
		this.context = context;
	}


	public void createFileProfile(String filename){

		//intialize the file
		File file_profile=new File(context.getFilesDir(),filename);

		try {
			//create the profile file
			file_profile.createNewFile();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In FileStatus createFileProfile(),Exception- "+e.getLocalizedMessage());


		}
	}

	public void createFileActivity(String filename){

		//intialize the activity file

		File file_activity=new File(context.getCacheDir(),filename);

		try {

			file_activity.createNewFile();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In FileStatus createFileActivity(),Exception- "+e.getLocalizedMessage());

		}
	}
	public String readfromfile(String filename)
	{
		String text="";

		byte[] data;

		try {
			//intialize the file
			File file=new File(context.getFilesDir(),filename);
			//read the data
			if(file.isFile())
			{
				data=new byte[(int) file.length()];

				FileInputStream inputStream=context.openFileInput(filename);

				inputStream.read(data);

				text=new String(data);

				inputStream.close();


			}



		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In FileStatus readfromfile(),Exception- "+e.getLocalizedMessage());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In FileStatus readfromfile(),Exception- "+e.getMessage());

		}


		return text;  
	}
	public boolean isFile(String filename){

		//check the presence of the file

		File file=new File(context.getCacheDir(),filename);

		return file.isFile();
	}

	public void writetofile(String filename,String text){

		try {

			//write the data on the file 
			FileOutputStream outputStream=context.openFileOutput(filename, Context.MODE_PRIVATE);

			outputStream.write(text.getBytes());

			outputStream.close();


		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In filestatus writetofile(),Exception- "+e.getLocalizedMessage());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/*public void readActivityStatus(String filename){

		File file=new File(context.getCacheDir(),"Activity");
		//file.c

	}*/

	public void writeFriendList(String Filename,ArrayList<String> list){

		FileOutputStream outputStream;
		ObjectOutputStream object;
		try {
			outputStream = context.openFileOutput(Filename,context.MODE_PRIVATE);
			object=new ObjectOutputStream(outputStream);

			object.writeObject(list);
			
			object.close();
			outputStream.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public ArrayList<String> fetchFriendlist(String name){
		
		FileInputStream inputStream;
		ObjectInputStream object;
		ArrayList<String> list=new ArrayList<String>();
	
		try {
			
			inputStream=context.openFileInput(name);
			object=new ObjectInputStream(inputStream);
			
			list=(ArrayList<String>)object.readObject();
			 
			object.close();
			inputStream.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (StreamCorruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
		return list;
	}


}
