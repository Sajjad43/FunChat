package com.example.text;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.widget.ListView;

public class DisplayContactList extends Thread{

	String activity_name="";
	Context context;
	ArrayList<String> Name_list;
	ArrayList<String> Number_list;
	ListView list;

	public DisplayContactList(String activity_name, Context context,
			ArrayList<String> name_list, ArrayList<String> number_list,
			ListView list) {
		super();
		this.activity_name = activity_name;
		this.context = context;
		Name_list = name_list;
		Number_list = number_list;
		this.list = list;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();

		Log.d("Sajjad","Display Contact- "+activity_name);
		Log.d("Sajjad","ListView- "+((Second_activity)context).listview);

		if(list!=null)
		{
			list.post(new Runnable(){


				@Override
				public void run() {
					// TODO Auto-generated method stub

					if(activity_name.equals("second"))
					{
						Log.d("Sajjad","Display Contact1- "+activity_name);

						//((Second_activity)context).dialog.dismiss();
						
						//((Second_activity)context).dialog.cancel();

						Log.d("Sajjad","Display Contact1- "+activity_name);

						((Second_activity)context).adapter=new SecondActivity_Adapter(context,Name_list,Number_list);

						((Second_activity)context).listview.setAdapter(((Second_activity)context).adapter);

					}
					else if(activity_name.equals("group")){

						((Group_imageActivity)context).adapter=new GroupImage_NavAdapter(context,Name_list,Number_list);
						list.setAdapter(((Group_imageActivity)context).adapter);



					}

				}

			});

		}
	}




}
