package com.example.text;

import java.util.ArrayList;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;


public class Notification_Activity extends Activity implements OnItemClickListener {

	ListView listView;
	Notifi_Adapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.notify_activity);
		//set the actionbar title
		ActionBar actionBar=this.getActionBar();
		actionBar.setSubtitle("Notification");


		Log.d("Sajjad","NotificationActivity");
		//listview of the notication
		listView=(ListView)this.findViewById(R.id.listView_notify);
		listView.setOnItemClickListener(this);



	}


	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		//if there is no elements in the arraylist ,then return back to second Activity 
		if(Service_Socket.service.notification.size()==0){

			this.finish();
		}


		else{

			//set the adapter to listView
			Log.d("Sajjad","Notification array size is"+Service_Socket.service.notification.size());
			adapter=new Notifi_Adapter(this,Service_Socket.service.notification); 
			listView.setAdapter(adapter);


		}


	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.notification, menu);
		return true;
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub

		if(item.getItemId()==R.id.home){

			Intent intent=new Intent(this,Second_activity.class);
			this.startActivity(intent);
			//close the notification activity
			this.finish();  

			//if there is unseen notification left ,notify again 
			if(Service_Socket.service.notification.size()!=0)
			{
				//notify 
				Notificate notifi=new Notificate(3);
				notifi.notifies();


			}

		}

		return true;
	}


	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub

		//get the name of the item clicked in the list view
		TextView name=(TextView) view.findViewById(R.id.name);
		String nam=name.getText().toString();

		Log.d("Sajjad","In Notification Activity,Name is -"+nam); 

		Notitype i= (Notitype) parent.getItemAtPosition(position);
		
		if(i!=null){


			//if type is 1 ,then it is image
			if(i.getType()==1){

				//start third activity 
				Intent intent =new Intent(this,Third_Activity.class);
				intent.putExtra("imagename",i.getFilename_message());
				intent.putExtra("SenderName",Service_Socket.service.mapService.get(i.getNumber()).getName());
				intent.putExtra("senderNumber", i.getNumber());
				Service_Socket.service.notification.remove(i);
				this.startActivity(intent);
 


			}
			//if type is 2,then it is message
			
			else if(i.getType()==2){

				//start  third activity
				Intent intent =new Intent(this,Third_Activity.class);
				intent.putExtra("senderNumber",i.getNumber());
				intent.putExtra("SenderName",Service_Socket.service.mapService.get(i.getNumber()).getName());
				intent.putExtra("message",i.getFilename_message());


				Service_Socket.service.notification.remove(i);

				this.startActivity(intent);


			}


		}
	}

	public Notitype getNotitype(String name){

		for(int i=0;i<Service_Socket.service.notification.size();i++){


			if(name.equals(Service_Socket.service.notification.get(i).getName())){

				return Service_Socket.service.notification.get(i);

			}
 
		}

		return null;
	}


	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();


		if(Service_Socket.service.notification.size()!=0)
		{
			Notificate notifi=new Notificate(3);
 			notifi.notifies();
		}

	}



}
