package com.example.text;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.util.Log;

public class Image_downloadsocket extends Thread{

	Socket socket;
	DataInputStream inputStream;
	DataOutputStream outputStream;
	int noOffile;
	String imagename="";
	String sendernumber="";
	byte[] data;
	String sendername;
	int no=0;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		Log.d("Sajjad","Image download");

		try {
			//read the mobile user name and number from the File 
			socket=new Socket(IP.Ip,6001);
			inputStream=new DataInputStream(socket.getInputStream());
			outputStream=new DataOutputStream(socket.getOutputStream());
			//get the name,number of the mobile user
			String userNameAndphone=readfile();
			String[] namePhone=new String[2];
			namePhone=userNameAndphone.split(" ");	

			//send the name and the number of the mobile user to server
			outputStream.writeUTF(namePhone[0]);
			outputStream.writeUTF(namePhone[1]);

			Log.d("Sajjad",namePhone[0]+"and"+namePhone[1]+"are sent" );

			while(true){
				//send the mobile number to the server
				outputStream.writeUTF(namePhone[1]);
 				//read the no of image file from the server
				noOffile=inputStream.readInt();
 
				if(noOffile>0){

					for(int i=0;i<noOffile;i++){

						//read the sendername and the filename
						sendernumber=inputStream.readUTF();
						imagename=inputStream.readUTF();
						//read the byte array size
						int datasize=inputStream.readInt();
						data=new byte[datasize];
						//read the byte array
						inputStream.readFully(data);

						Log.d("Sajjad","In download image,ImageFile-"+imagename+"sent by "+sendernumber);
						
						
						//decode the byte array to bitmap
						BitmapFactory.Options option=new BitmapFactory.Options();
						option.inSampleSize=2;
						
						BitmapFactory factory=new BitmapFactory();
						
						Bitmap bitmap=factory.decodeByteArray(data,0, data.length,option);
					
						
						//ActivityStatus() is used to check whether activity thread is visible or not .If visible broadcast the intent so that image 
						//can be placed on the activity without doing nothing .If not visible ,send a notification
						
						if(ActivityStatus()){

							Log.d("Sajjad", "ImageSocket- Activity Status for image is yes");
							 
							//save the bitmap to sd card
							
							//BitmapSdCard sdCard=new BitmapSdCard();
						    //sdCard.writeImage(bitmap, imagename);
							
							 storeinSdcard(bitmap);
								
							
							//send local broadcast intent to receiver in third activity
							Intent intent=new Intent("com.example.text.Third_Activity1");
							intent.putExtra("imagename",this.imagename);
							Service_Socket.service.sendBroadcast(intent);
							Log.d("Sajjad", "Image intent send broadcast");

						}
						else{
							//save the bitmap to sd card
							storeinSdcard(bitmap);
							
							Notificate notifi=new Notificate(Service_Socket.service.mapService.get(this.sendernumber).getName(),sendernumber,
									this.imagename,1);
							notifi.notifies();
							Log.d("Sajjad", "send notification");

						}
 
					}
				}
				Thread.sleep(2000);

			}


		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","Imagedownload exception");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","Imagedownload exception");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","Imagedownload exception");
		}

	}
	public String readfile(){
		 
		FileStatus file=new FileStatus(Service_Socket.service);
		return file.readfromfile("profile");
 
	}
	public void  storeinSdcard(Bitmap bitmap){
	 //save the image file		
		BitmapSdCard sdCard=new BitmapSdCard();
		sdCard.writeImage(bitmap, imagename);
 
	}
 
	public boolean ActivityStatus(){
		
		String[] string=new String[2];
		boolean status=false;
		FileStatus file=new FileStatus(Service_Socket.service);

		Log.d("Sajjad","Imagedownload- check Activity status" );

		String file_status=file.readfromfile("Activity");
		Log.d("Sajjad","File status -"+file_status);

		if(file_status.equals("Nothing")){
			status=false;
		}

		else{
			string=file.readfromfile("Activity").split(" ");
			Log.d("Sajjad",string[0]+" "+string[1]);

			if(string[0].equals("ActivityTwo")){
				if(string[1].equals(this.sendernumber))
				{
					status=true;
				}
				else{
					status=false;
				}
			}

		}

		return status;
	}
}
