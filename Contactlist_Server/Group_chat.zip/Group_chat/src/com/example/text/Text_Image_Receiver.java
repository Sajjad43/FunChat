package com.example.text;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import android.widget.ScrollView;

public class Text_Image_Receiver extends BroadcastReceiver{

	
	String message="";
	String imagename="";
	Bitmap bitmap;
	Context CoNtext;
	
	
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		Log.d("Sajjad", "Text Broadcast intent receive");
		  this.CoNtext=context;
		 message=intent.getStringExtra("message");
		 imagename=intent.getStringExtra("imagename");
		 
		 Log.d("Sajjad", "The message is"+message);
		
		 if(message!=null)
		 {
			((Third_Activity)context).messaging.addViewforMessageReceive(message);
			((Third_Activity)context).messaging.scrollview.postDelayed(new Runnable(){

				@Override
				public void run() {
					// TODO Auto-generated method stub
					 Messaging.fragments.scrollview.fullScroll(ScrollView.FOCUS_DOWN);
				}
				
			},150);
			
			
		 }
		if(imagename!=null){
			   
			  Log.d("Sajjad","Image receiver");
			  new Thread(new Runnable(){

				@Override
				public void run() {
					// TODO Auto-generated method stub
				
					Thread thread=new Thread(new Runnable(){

						@Override
						public void run() {
							// TODO Auto-generated method stub
							BitmapSdCard sdCard=new BitmapSdCard();
							bitmap=sdCard.readImage(imagename);
						}
						
					});
					thread.start();
					try {
						thread.join();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					((Third_Activity)CoNtext).messaging.addImageView(bitmap,imagename);
					
				}
				  
			  }).start();
		

		}
		
		
		
		
	}

}
