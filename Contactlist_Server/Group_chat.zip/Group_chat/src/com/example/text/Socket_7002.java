package com.example.text;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import android.app.FragmentManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;

public class Socket_7002 extends Thread{

	Event_Activity activity;
	 
	DataInputStream inputStream;
	String catagory="";
	DataOutputStream outputStream;
	ArrayList<Event_item> array =new  ArrayList<Event_item>();

	Socket socket1;
	String title="",address="",url="",time="",date="";

	public Socket_7002(Event_Activity activity) {
		super();
		this.activity = activity;
	}

	@Override
	public void run(){
		try {

			socket1=new Socket(IP.Ip,7002);
			Log.d("Sajjad","Socket 7001 running");

			this.outputStream=new DataOutputStream(socket1.getOutputStream());
			this.inputStream=new DataInputStream(socket1.getInputStream());


			String userNameAndphone=readfile();
 			Log.d("Sajjad", "The username and phone are"+userNameAndphone);
			String[] namePhone=new String[2];
			namePhone=userNameAndphone.split(" ");
			outputStream.writeUTF(namePhone[1]);
			Log.d("Sajjad","The phonenumber of the client "+ namePhone[1]);

			while(true){
	
				//fetch the no of item for the event catagory
				int size=inputStream.readInt();
				
				for(int i=0;i<size;i++){
				 
					//get the information for the event item 
					title=inputStream.readUTF();
					address=inputStream.readUTF( );
					date=inputStream.readUTF();
					time=inputStream.readUTF();
					url=inputStream.readUTF();
				
					/*Bitmap bitmap=BitmapFactory.decodeResource(activity.getResources(), R.drawable.success);
					
					Bitmap temp = bitmap.createScaledBitmap(bitmap, 100, 200, true);
					
					BitmapDrawable bDraw = new BitmapDrawable(activity.getResources(),temp); */
					 
						Bitmap  bitmap=BitmapFactory.decodeResource(activity.getResources(), R.drawable.freedom);
						array.add(new Event_item(title,address,date,time,url,bitmap));
						
 
				 }

 
				Log.d("Sajjad","Got the event object in arraylist "+array.size());


				activity.runOnUiThread(new Runnable(){

					@Override
					public void run() {
						// TODO Auto-generated method stub

						//create a event fragment and add it to the activity 
						FragmentManager manager=activity.getFragmentManager();
 						activity.fragment=new Event_Fragment(catagory,array);
 						manager.beginTransaction().replace(R.id.content_frame, activity.fragment).commit();
						array=new  ArrayList<Event_item>();

					}

				});

			}
		}catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In socket 7002 run(),Exception- "+e.getLocalizedMessage() );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("Sajjad","In socket 7002 run(),Exception- "+e.getLocalizedMessage() );
		}

	}

	 
	public String getCatagory() {
		return catagory;
	}

	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	
	public String readfile(){

		FileStatus file=new FileStatus(Service_Socket.service);
 		return file.readfromfile("profile");


	}
}
