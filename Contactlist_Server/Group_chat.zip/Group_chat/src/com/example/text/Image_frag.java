package com.example.text;

import java.io.ByteArrayOutputStream;

import java.io.IOException;



import android.app.Fragment;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class Image_frag extends Fragment implements OnClickListener{

	String uri="";
	byte [] data;
	EditText editext;
	Bitmap bitmap;
	String[] namePhone;

	public Image_frag(String uri) {

		this.uri = uri;

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		Log.d("Sajjad","IMageFragment");

		//extract the View
		View view=inflater.inflate(R.layout.image_frag,null);
		ImageView image=(ImageView)view.findViewById(R.id.fullimageView2);
		editext=(EditText)view.findViewById(R.id.fulleditText2);
		Button button=(Button)view.findViewById(R.id.fullbutton2);
		button.setOnClickListener(this);
		
		//load the image
		ImageLoading_SDcard imageloading=new ImageLoading_SDcard(image,Uri.parse(uri),this.getActivity(),1);
		imageloading.start();

		//get the mobile user name and the number
		String userNameAndphone=readfile();
		namePhone=new String[2];
		namePhone=userNameAndphone.split(" ");	

		Log.d("Sajjad", "IN ImageFragment,The username and phone are "+userNameAndphone);

  
		return  view;
	}

	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		System.out.println(Group_imageActivity.selectedname);

	
		new Thread(new Runnable(){
			@Override
			public void run() {
				// TODO Auto-generated method stub

				//convert the bitmap to byte array
				ByteArrayOutputStream outputStream=new ByteArrayOutputStream();

				if(bitmap.compress(CompressFormat.JPEG, 50,outputStream)){

					data=new byte[outputStream.toByteArray().length];
					data=outputStream.toByteArray();

				}
				//sent the friend list,friend list size,byte array, byte size,filename,mobile user number
				try {

					Service_Socket.service.imageupload. outputStream.writeUTF(namePhone[1]);

					Service_Socket.service.imageupload. outputStream.writeUTF(editext.getText().toString());

					Service_Socket.service.imageupload. outputStream.writeInt(Group_imageActivity.selectedname.size());

					for(int i=0;i<Group_imageActivity.selectedname.size();i++){


						Log.d("Sajjad","The list is "+Group_imageActivity.selectedname.get(i));

						Service_Socket.service.imageupload.outputStream.writeUTF(Group_imageActivity.selectedname.get(i));

					}



					Service_Socket.service.imageupload.outputStream.writeInt(data.length);
					Service_Socket.service.imageupload.outputStream.write(data,0,data.length);

					Log.d("Sajjad","Bitmap sent from ImageFragment");


				} catch (IOException e){
					// TODO Auto-generated catch block
					Log.d("Sajjad","In Imagefrag onclick(),Exception- "+e.getLocalizedMessage());
				}

			}

		}).start();

		//close the GroupImage activity
		this.getActivity().finish();




	}


	public String readfile(){
		//read the mobile user name and number from the File 
		FileStatus file=new FileStatus(Service_Socket.service.getApplicationContext());
		return file.readfromfile("profile");


	}




}
