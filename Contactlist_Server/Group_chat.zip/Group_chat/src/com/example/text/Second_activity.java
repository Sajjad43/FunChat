
package com.example.text;
import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class Second_activity extends FragmentActivity implements OnItemClickListener,PopupMenu.OnMenuItemClickListener{

	/* (non-Javadoc)
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	static Second_activity second;
	Socket_7001 socket;
	String number_listItem;
	String name_listItem,username;
	EditText editText;
	ListView listview;
	//Map<String,String> map=new HashMap<String,String>();
	ArrayList<String> Name_list;
	ArrayList<String> Number_list;
	SecondActivity_Adapter adapter;
	ProgressDialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		second=this;

		setContentView(R.layout.activity_two);

		// arraylist to store list of name and number
		Name_list=new ArrayList<String>();
		Number_list=new ArrayList<String>();

		//editext for the search
		editText=(EditText)this.findViewById(R.id.filter);
		//progress Dialog
		//dialog=ProgressDialog.show(this,"Contacts","Loading this");

		Log.d("Sajjad","Second Activity created");


		//know the service status
		FileStatus file=new FileStatus(this);
		String service_status=file.readfromfile("Service");
		Log.d("Sajjad","Secon Activity- The service is "+service_status);



		listview=(ListView) this.findViewById(R.id.listView1);
		listview.setOnItemClickListener(this);



		//get the list of name and number from the database
		//ContactsFromDatabase();
		LoadingContacts_thread contact=new LoadingContacts_thread(this,listview,Name_list,Number_list,"second");
		contact.start();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.second, menu);

		return true;
	}



	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if(item.getItemId()==R.id.action_settings){

			//show the popup menu
			PopupMenu menu=new PopupMenu(this,this.findViewById(R.id.action_settings));
			menu.inflate(R.menu.second_pop);
			menu.show();
			menu.setOnMenuItemClickListener(this);


		}
		return true;
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		//get the reference of the second activity
		second=this;

	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

	}
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Log.d("Sajjad","back button pressed");


	}
	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long arg3) {
		// TODO Auto-generated method stub

		//get the name and the number of the item clicked
		name_listItem=second.adapter.getItem(position);
		this.number_listItem=second.Number_list.get(position);



		Log.d("Sajjad","Activity_two item-Name:"+name_listItem+" Number: "+number_listItem);


		new Thread(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {

					Log.d("Sajjad",""+Service_Socket.service);	

					//send the name and number to the server for its presence in the server
					Service_Socket.service.socket_7001.outputStream.writeUTF(name_listItem);
					Service_Socket.service.socket_7001.outputStream.writeUTF(number_listItem.substring(number_listItem.length()-11,number_listItem.length()));

				} catch (IOException e) {
					// TODO Auto-generated catch block
					Log.d("Sajjad","In SecondActivity Onitemclickrun(),Exception- "+e.getMessage());

				}

			}


		}).start();




	}


	@Override
	public boolean onMenuItemClick(MenuItem item) {
		// TODO Auto-generated method stub

		if(item.getItemId()==R.id.Event){
			//start the event activity
			Intent intent=new Intent(this,Event_Activity.class);
			this.startActivity(intent);

		}

		if(item.getItemId()==R.id.Group_photo){

			Intent intent = new Intent();
			intent.setType("image/*");
			intent.setAction(Intent.ACTION_GET_CONTENT);
			startActivityForResult(Intent.createChooser(intent,"Select Image"),1);  

		}

		if(item.getItemId()==R.id.notification){

			//start the notification activity if any notification pending by checking the service Map for notification

			if(Service_Socket.service.notification.size()==0){

				Toast.makeText(getApplicationContext(), "No Notification", 2000).show();
			}
			else{
				
				Intent intent=new Intent(this,Notification_Activity.class);
				this.startActivity(intent);

			}


		}
		
		//todo list
		
		//add an item to the xml file to the popup menu
		//if the item click is Profile picture
		//start a intent for capture a profile picture 
		//use start activityfor result and add a requestCode to it i.e 6
		

		return true;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if(requestCode==1&&resultCode==RESULT_OK&&data!=null)
		{
			//start the group image activity  
			Intent intent=new Intent(this,Group_imageActivity.class);
			//send the uri of the selected image with the intent
			intent.putExtra("URI",data.getData().toString());

			this.startActivity(intent);
		}
		
		//if requestCode is 6
		// use the filepath,get the image and send the bitmap to the server via fetchFriends Socket
		
		
		
	}


}
