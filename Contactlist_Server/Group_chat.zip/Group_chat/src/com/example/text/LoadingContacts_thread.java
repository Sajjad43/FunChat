package com.example.text;

import java.io.DataInputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class LoadingContacts_thread extends Thread {

	Context context;
	ArrayList<String> Name_list;
	ArrayList<String> Number_list;
	ArrayList<String> FetchList;
	ListView list;
	String activity_name="";
	Socket socket;
	int flag;
	DataInputStream inputStream;

	public LoadingContacts_thread(Context context,ListView List,ArrayList<String> Name_list,
			ArrayList<String> Number_list,String activity_name){

		this.list=List;
		this.Name_list=Name_list;
		this.Number_list=Number_list;
		this.activity_name=activity_name;
		this.context=context;
		Log.d("Sajjad","Contacts Thread running ");

	}

	public LoadingContacts_thread(Context context, ArrayList<String> FetchList, int flag ) {
		super();
		this.context = context;
		this.FetchList = FetchList;
		this.flag=flag;

	}

	//todo list---
	//create a constructor  having a parameter arraylist of the fetch friend 

	public LoadingContacts_thread(Context context){
		this.context=context;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();


		if(Service_Socket.mapService!=null&&Service_Socket.service.mapService==null){
			Service_Socket.service.mapService=new HashMap<String,Person>();
		}

		ContactsFromDatabase();


	}

	public void ContactsFromDatabase(){

		Thread thread=new Thread(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub

				//start a new thread
				Thread thread2=new Thread(new Runnable(){

					@Override
					public void run() {
						// TODO Auto-generated method stub

						//initialize the content resolver
						ContentResolver resolver=context.getContentResolver();
						Cursor cursor=resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

						//index of the name and number column  of the contact contentprovider
						int name_column=cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
						int number_column=cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

						while(cursor.moveToNext())
						{ 
							if(cursor.getString(number_column).length()>=11)
							{ 
								//extract the name and number of the friends from the contentprovider
								String number=cursor.getString(number_column).substring(cursor.getString(number_column).length()-11 , cursor.getString(number_column).length());
								String name=cursor.getString(name_column);

								//if nameList arraylist is not null ,then add the name and number to
								//the arraylist
								if(Name_list!=null) 
								{
									if(!Number_list.contains(number)){
										Name_list.add(name);
										Number_list.add(number);

									}

								}

								//todo list----
								//if fetchfriend arraylist is not null, add the number to the fetch friend arraylist
								//---------
								if(FetchList!=null){

									if(!FetchList.contains(number)){
										FetchList.add(number);

									}
								}

								//if service is not null
								//a problem when app crash ,service stop,we have to wake it up again

								if(Service_Socket.service!=null){

									//todo list
									//create a person object using the name and  number parameters
									//add the object to the service MAp using number as the key
									if(!Service_Socket.service.mapService.containsKey(number)){


										Person person=new Person(null,name,number);
										Service_Socket.service.mapService.put(number,person);
									}
								}

							}
						}

						cursor.close();

					}



				});
				thread2.start();

				try {

					thread2.join();

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}



				Uri sim=Uri.parse("content://icc/adn");
				//get the contacts from the sim 
				ContentResolver resolver=context.getContentResolver();
				Cursor cursor=resolver.query(sim, null, null, null, null);
				//name and number index of the contacts content provider 
				int name_column=cursor.getColumnIndex("name");
				int number_column=cursor.getColumnIndex("number");

				while(cursor.moveToNext())
				{ 
					if(cursor.getString(number_column).length()>=11)
					{   
						String number=cursor.getString(number_column).substring(cursor.getString(number_column).length()-11 , cursor.getString(number_column).length());
						String name=cursor.getString(name_column);

						if(Name_list!=null){

							if(!Number_list.contains(number)){
								Name_list.add(name);
								Number_list.add(number);

							}

						}

						if(FetchList!=null){

							if(!FetchList.contains(number)){
								FetchList.add(number);

							}
						}


						//to do list
						//if service is not null
						if(Service_Socket.service!=null){

							//todo list--
							//create a person object using the name and  number parameters
							//add the object to the MAp using number as the key
							if(!Service_Socket.service.mapService.containsKey(number)){
								Person person=new Person(null,name,number);
								Service_Socket.service.mapService.put(number,person);

							}
 
						}

					}
				}
				cursor.close();


				//todo list--
				//if namelist is not null
				//start the friend image icon loading thread where all the image will be loaded and 
				//add to service Map using the number as the key to access 
				//here, use thread.join to stop the host thread until loading thread is done


				if(FetchList!=null){

					Log.d("Sajjad","Loading contacts-fetchsize is"+FetchList.size());

					SendFriendList send=new SendFriendList(context ,FetchList,flag);
					send.start();


				}





				if(Name_list!=null){


					Loading_FriendsIcon load=new Loading_FriendsIcon(activity_name,context,Name_list,Number_list,list);
					load.start();

				}


				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					Log.d("Sajjad","In SecondActivity COntactDatabase,Exception- "+e.getMessage());

				}
				/*
				if(list!=null)
				{
					list.post(new Runnable(){


						@Override
						public void run() {
							// TODO Auto-generated method stub

							if(activity_name.equals("second"))
							{
								((Second_activity)context).dialog.dismiss();

								((Second_activity)context).dialog.cancel();

								((Second_activity)context).adapter=new SecondActivity_Adapter(context,Name_list,Number_list);

								list.setAdapter(((Second_activity)context).adapter);

							}
							else if(activity_name.equals("group")){

								((Group_imageActivity)context).adapter=new GroupImage_NavAdapter(context,Name_list,Number_list);
								list.setAdapter(((Group_imageActivity)context).adapter);



							}

						}

					});

				}*/
			}





		});

		thread.start();

	}







}