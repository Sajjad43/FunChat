package com.example.text;

import java.io.File;
import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Environment;
import android.util.Log;
import android.widget.ListView;

public class Loading_FriendsIcon extends Thread{

 
	String activity_name="";
	Context context;
	ArrayList<String> Name_list;
	ArrayList<String> Number_list;
	ListView list;
 
	public Loading_FriendsIcon(String activity_name, Context context,
			ArrayList<String> name_list, ArrayList<String> number_list,
			ListView list) {
		super();
		this.activity_name = activity_name;
		this.context = context;
		Name_list = name_list;
		Number_list = number_list;
		this.list = list;
	}
 
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		 
		//initialize the file ,using the path specify
		//get the filelist
		//use a loop ,set filelist length as the limit
		//get the file path
		//separate the number from the file name
	 	//load the image
		//add the image to the ServiceMap using the number as key
		
		File file=new File(Environment.getExternalStorageDirectory()+"/DCIM/FunChat/");
		File [] file_array=new File[file.listFiles().length]; 
		file_array=file.listFiles();
		
		BitmapSdCard sd=new BitmapSdCard();
		
		for(int i=0;i<file.listFiles().length;i++){
			
			Bitmap bitmap=sd.readFriendImage(file_array[i].getAbsolutePath());
		 	
			if(file_array[i].getName().length()>=11){
				
				String number=file_array[i].getName().substring(0,11);	
				Log.d("Sajjad","LoadingFriends Icon name -"+number);
				
				 
				
				if(number!=null){
					Service_Socket.service.mapService.get(number).setImage(bitmap);
					
				}
			 
			}
			
		}
		
		DisplayContactList display=new DisplayContactList(activity_name,context, Name_list, Number_list,list);
		display.start();
		
		 
	}

}
