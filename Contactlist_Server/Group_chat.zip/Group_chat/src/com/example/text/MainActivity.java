package com.example.text;



import android.os.Bundle;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener{


	EditText user_name,phone_number;
	static MainActivity main;
	Button login;
	FileStatus file;
	ProgressDialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		main=this;

		Log.d("Sajjad",IP.Ip);

		//check the network
		NetworkCheck network=new NetworkCheck(this);

		Log.d("Sajjad","MainActivity- The network is- "+network.isConnected());

		//check the activity status
		file=new FileStatus(this);

		Log.d("Sajjad","MainActivity- The activity status is"+file.isFile("ActivityOne"));

		if(network.isConnected())
		{
			if(!file.isFile("ActivityOne"))
			{
				setContentView(R.layout.activity_main);
				main=this;
				Log.d("Sajjad","MainActivity- Activity one running");

				 
				
				//initialize the login button and ueredittext
				
				
				login=(Button)MainActivity.main.findViewById(R.id.button1); 
				phone_number=(EditText)this.findViewById(R.id.editText2);
				user_name=(EditText)this.findViewById(R.id.editText1);
				login.setOnClickListener(this);
			}
			else{

				
				 
				
				
				String service_status="";


				//decision of starting a service

				if(file.isFile(("Service"))){

					//know the service status
					service_status=file.readfromfile("Service");
					Log.d("Sajjad","MainActivity- The service is "+service_status);

					if(service_status.equals("true")&&Service_Socket.service!=null){
						//service is ruuning	
						Intent intent=new Intent(this,Second_activity.class);
						this.startActivity(intent);
						this.finish();
					}
					else
					{   
						AlertDialog.Builder builder=new AlertDialog.Builder(this);
						builder.setTitle("Fun_CHat");
						builder.setMessage("Wait for the service to start");

						builder.setPositiveButton("OK",new DialogInterface.OnClickListener(){

							@Override
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
								 Intent intent =new Intent(main.getApplicationContext(),Second_activity.class);
								 main.startActivity(intent);
							}
						});
						builder.create().show();
						
						
						//no service running,so start a service
						Intent intentService=new Intent(this,Service_Socket.class);
						this.startService(intentService);
						
						
						
					}
				}
				else{


				 
						//start the service, if there is no service 
						Intent intentService=new Intent(this,Service_Socket.class);
						this.startService(intentService);
						
				  
					 

				}
				//start the second activity if activity one,the login part done,

			 /*
					Intent intent=new Intent(this,Second_activity.class);
					this.startActivity(intent);
					this.finish();
				*/
			}
		}
		else{
			//No internet connection
			AlertDialog.Builder builder=new AlertDialog.Builder(this);
			builder.setTitle("Fun_CHat");
			builder.setMessage("Turn on your internet and get back to funchat");

			builder.setPositiveButton("OK",new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					main.finish();
				}
			});
			builder.create().show();

		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub


		Log.d("Sajjad","MainActivity,Username- "+user_name.getText().toString()+"and Phone- "+phone_number.getText().toString());

		Socket_7000 socket=new Socket_7000(this,user_name.getText().toString(),phone_number.getText().toString());
		socket.start();

	}



}
