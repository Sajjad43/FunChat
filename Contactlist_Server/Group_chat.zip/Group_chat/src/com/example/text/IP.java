package com.example.text;

public class IP {
	//set the ip and the port
	static String Ip="192.168.137.1";
	static	int port1=7000;
	static	int port2=7001;
	static	int port3=8000;
	//192.168.137.1
   //108.61.181.112

}
