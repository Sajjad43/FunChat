package com.example.text;

import java.io.ByteArrayOutputStream;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class Full_Image extends Activity implements OnClickListener{

	String url="",chatNumber="",chatperson="";
	byte[] data;
	EditText edit;
	Bitmap bitmap=null;
	ImageView imageView;
	Uri uri;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		this.setContentView(R.layout.image2);
		//imageview for the image
		imageView=(ImageView)this.findViewById(R.id.fullimageView);

		//edittext for the filename
		edit=(EditText)this.findViewById(R.id.fulleditText);



		Button button=(Button)this.findViewById(R.id.fullbutton);
		button.setOnClickListener(this);



		//get the details from intent
		Intent intent=this.getIntent();
		 
		this.chatperson=intent.getStringExtra("chatperson");
		this.chatNumber=intent.getStringExtra("chatnumber");
		this.url=intent.getStringExtra("url");
		this.getActionBar().setSubtitle(chatperson);



		//decode the image
		this.decodeUri(Uri.parse(url)); 
	 

	}
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		//decode the file and get the image

		//send the image to the server
		new Thread(new Runnable(){





			@Override
			public void run() {
				// TODO Auto-generated method stub



				//Bitmap bitmap=BitmapFactory.decodeFile(filename);
				if(bitmap!=null)
				{
					//convert the bitmap to byte array
					ByteArrayOutputStream outputStream=new ByteArrayOutputStream();
 
					if(bitmap.compress(CompressFormat.JPEG, 50,outputStream)){

						data=new byte[outputStream.toByteArray().length];
						data=outputStream.toByteArray();

					}

  					try {

  						//send the byte size ,array, filename,number of the mobile the file is sent
  						
  						Service_Socket.service.imageSocket.dataOutputStream.writeUTF(chatNumber);
						Service_Socket.service.imageSocket.dataOutputStream.writeUTF(edit.getText().toString());

						Service_Socket.service.imageSocket.dataOutputStream.writeInt(data.length);
						Service_Socket.service.imageSocket.dataOutputStream.write(data,0,data.length);
						

					} catch (IOException e) {
						// TODO Auto-generated catch block
						Log.d("Sajjad","In fullImage onclick(),Exception- "+e.getLocalizedMessage());
					}
				}
			}

		}).start();

		this.finish();

	}

	public void decodeUri(Uri u) {

		this.uri=u;
		//load the image from sd card based on the uri
		ImageLoading_SDcard loading=new ImageLoading_SDcard(imageView,uri,this,2);
		loading.start();
	}


}
